package com.ahq.globals.utilities;

import java.util.Random;

public class UtilVehicleReg {

    public static String generate(String country, String prefixValue) {
        switch (country.toUpperCase()) {

            case "SINGAPORE":
            case "SGP":
                return generateSingaporeVehicleReg(prefixValue);

            case "AUSTRALIA":
            case "AUS":
                return generateAustraliaVehicleReg();

            default:
                return "VEHICLE REG NUMBER - <country not supported>";

        }
    }

    private static String generateSingaporeVehicleReg(String prefix) {
        Random random = new Random();
//        String prefix = generateSingaporePrefix(random);
        String number = String.format("%04d", random.nextInt(10000));
        char checksum = calculateSingaporeChecksum(prefix, number);
        return prefix + number + checksum;
    }

    private static String generateSingaporePrefix(Random random) {
        String[] prefixes = {"S", "E", "T", "G", "Y", "SM", "SL", "SK"};
        return prefixes[random.nextInt(prefixes.length)];
    }

    private static char calculateSingaporeChecksum(String prefix, String number) {
        int[] weights = {9, 4, 5, 4, 3, 2};
        char[] checksumLetters = {
                'A', 'Z', 'Y', 'X', 'U', 'T', 'S', 'R', 'P', 'M',
                'L', 'K', 'J', 'H', 'G', 'E', 'D', 'C', 'B'
        };

        String fullInput;
        if (prefix.length() == 1) {
            fullInput = "0" + prefix + number;
        } else if (prefix.length() == 2) {
            fullInput = prefix + number;
        } else {
            fullInput = prefix.substring(1) + number;
        }

        int totalWeight = 0;
        for (int i = 0; i < fullInput.length(); i++) {
            char c = fullInput.charAt(i);
            int value = Character.isLetter(c) ? c - 'A' + 1 : Character.getNumericValue(c);
            totalWeight += value * weights[i];
        }

        int remainder = totalWeight % 19;
        return checksumLetters[remainder];
    }

    private static String generateAustraliaVehicleReg() {
        Random random = new Random();
        StringBuilder regNumber = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            if (random.nextBoolean()) {
                regNumber.append(random.nextInt(10));
            } else {
                regNumber.append((char) ('A' + random.nextInt(26)));
            }
        }
        return regNumber.toString();
    }

    public static void main(String[] args) {
        String singaporeReg = generate("SINGAPORE","SDP");
        System.out.println("Generated Singapore Vehicle Number: " + singaporeReg);
//        https://vrn.sg/singapore-car-plate/
//        https://carplatemart.sg/simple-checksum/
//        https://jayl.io/

        String australiaReg = generate("AUSTRALIA","");
        System.out.println("Generated Australia Vehicle Number: " + australiaReg);
    }
}