package com.ahq.globals;


import com.ahq.addons.d365Loc;
import com.ahq.addons.patternLoc;
import com.qmetry.qaf.automation.step.QAFTestStep;
import io.cucumber.java.en.And;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

public class D365Finance {

    @QAFTestStep(description="D365-Fin: Login to {0} with following details Url:{1}, Username:{2} and Password:{3}")
    @And("D365-Fin: Login to {string} with following details Url:{string}, Username:{string} and Password:{string}")
    public static void d365Fin_loginTo(String name, String urlToOpen, String username, String password) throws Exception{
        web.openBrowserAndMaximise_Web(urlToOpen);
        web.inputTextWithPlaceholderOrNoLabel_Web(username,"someone@example.com");
        web.clickButton_Web("Next");
        BrowserGlobal.iWaitForPageToLoad();
        web.verifyPageHeaderText_Web("Login","Login");
        web.removeFieldLocation_Web();;
//        BrowserGlobal.iWaitForSeconds("2");
        web.clickButton_Web("Brisbane Catholic Education");
        web.inputText_Web(username,"Username");
        web.inputText_Web(password,"Password");
        web.clickButton_Web("Login");
    }

    @QAFTestStep(description = "D365-Fin: Verify-Page-Header Text:{0} Page:{1}")
    @And("D365-Fin: Verify-Page-Header Text:{string} Page:{string}")
    public static void d365Fin_verifyPageHeader(String header_text,String page) throws Exception {
        web.waitForLoaderToDisappear_Web("Please wait. We're processing your request.");
        web.verifyPageHeaderText_Web(header_text,page+"::header_bar");
        web.removeFieldLocation_Web();
    }

    @QAFTestStep(description = "D365-Fin: Verify-User-Profile-Initial Text:{string} Page:{string}")
    @And("D365-Fin: Verify-User-Profile-Initial Text:{string} Page:{string}")
    public static void d365Fin_verifyUserProfileInitial(String initial_text,String page) throws Exception {
        web.verifyPageText_Web(initial_text,page+"::nav_bar");
        web.removeFieldLocation_Web();
    }


    @QAFTestStep(description = "D365-Fin: Verify-Page-Title Text:{0} Page:{1}")
    @And("D365-Fin: Verify-Page-Title Text:{string} Page:{string}")
    public static void d365Fin_verifyPageTitle(String title_text,String page) throws Exception {
        BrowserGlobal.iWaitForPageToLoad();
        web.waitForLoaderToDisappear_Web("Please wait. We're processing your request.");
        BrowserGlobal.iAssertTitleText(title_text);
        web.setPageName_Web(page);
    }

    /**
     * @param mainMenu_text [Main Menu Text/name to be clicked]
     * @param subMenu_text [Sub Menu Text/name to be clicked]
     */
    @And("D365-Fin: Click-Left-Menu Text:{string} Then-Sub-Menu Text:{string}")
    @QAFTestStep(description = "D365-Fin: Click-Left-Menu Text:{0} Then-Sub-Menu Text:{1}")
    public static void d365Fin_clickLeftMenuAndSubMenu(String mainMenu_text,String subMenu_text) throws Exception {
        web.setFieldLocation_Web("left_menu");
        web.clickLink_Web(mainMenu_text);
        web.waitForSecs_Web("2");
        web.clickLink_Web(subMenu_text);
        web.removeFieldLocation_Web();
    }

    /**
     * @param mainMenu_text [Main Menu Text/name to be clicked]
     * @param subMenu_1 [Sub Menu 1 Text/name to be clicked]
     * @param subMenu_2 [Sub Menu 2 Text/name to be clicked]
     */
    @And("D365-Fin: Click-Left-Menu-With-Two-Sub-Menus Text:{string} Sub-Menu_1:{string} Sub-Menu_2:{string}")
    @QAFTestStep(description = "D365-Fin: Click-Left-Menu-With-Two-Sub-Menus Text:{string} Sub-Menu_1:{string} Sub-Menu_2:{string}")
    public static void d365Fin_clickLeftMenuAndTwoSubMenus(String mainMenu_text,String subMenu_1,String subMenu_2) throws Exception {
        web.setFieldLocation_Web("left_menu");
        web.clickLink_Web(mainMenu_text);
        web.waitForSecs_Web("2");
        web.clickLink_Web(subMenu_1);
        web.setFieldLocation_Web("left_menu_expand");
        web.clickButton_Web("Collapse all");
        web.clickLink_Web(subMenu_2);
        web.removeFieldLocation_Web();
    }

    /**
     * @param mainMenu_text [Main Menu Text/name to be clicked]
     * @param subMenu_1 [Sub Menu 1 Text/name to be clicked]
     * @param subMenu_2 [Sub Menu 2 Text/name to be clicked]
     * @param subMenu_3 [Sub Menu 3 Text/name to be clicked]
     */
    @And("D365-Fin: Click-Left-Menu-With-Three-Sub-Menus Text:{string} Sub-Menu_1:{string} Sub-Menu_2:{string} Sub-Menu_3:{string}")
    @QAFTestStep(description = "D365-Fin: Click-Left-Menu-With-Three-Sub-Menus Text:{string} Sub-Menu_1:{string} Sub-Menu_2:{string} Sub-Menu_3:{string}")
    public static void d365Fin_clickLeftMenuAndThreeSubMenus(String mainMenu_text,String subMenu_1,String subMenu_2,String subMenu_3) throws Exception {
        web.setFieldLocation_Web("left_menu");
        web.clickLink_Web(mainMenu_text);
        web.waitForSecs_Web("2");
        web.clickLink_Web(subMenu_1);
        web.setFieldLocation_Web("left_menu_expand");
        web.clickButton_Web("Collapse all");
        web.clickLink_Web(subMenu_2);
        web.waitForSecs_Web("2");
        web.clickLink_Web(subMenu_3);
//        web.clickLink_Web(subMenu_text);
        web.removeFieldLocation_Web();
    }

    /**
     * @param mainMenu_text [Main Menu Text/name to be clicked]
     * @param subMenu_1 [Sub Menu 1 Text/name to be clicked]
     * @param subMenu_2 [Sub Menu 2 Text/name to be clicked]
     * @param subMenu_3 [Sub Menu 3 Text/name to be clicked]
     * @param subMenu_4 [Sub Menu 3 Text/name to be clicked]
     */
    @And("D365-Fin: Click-Left-Menu-With-Four-Sub-Menus Text:{string} Sub-Menu_1:{string} Sub-Menu_2:{string} Sub-Menu_3:{string} Sub-Menu_4:{string}")
    @QAFTestStep(description = "D365-Fin: Click-Left-Menu-With-Four-Sub-Menus Text:{string} Sub-Menu_1:{string} Sub-Menu_2:{string} Sub-Menu_3:{string} Sub-Menu_4:{string}")
    public static void d365Fin_clickLeftMenuAndFourSubMenus(String mainMenu_text,String subMenu_1,String subMenu_2,String subMenu_3,String subMenu_4) throws Exception {
        web.setFieldLocation_Web("left_menu");
        web.clickLink_Web(mainMenu_text);
        web.waitForSecs_Web("2");
        web.clickLink_Web(subMenu_1);
        web.setFieldLocation_Web("left_menu_expand");
        web.clickButton_Web("Collapse all");
        web.clickLink_Web(subMenu_2);
        web.waitForSecs_Web("1");
        web.clickLink_Web(subMenu_3);
        web.waitForSecs_Web("1");
        web.clickLink_Web(subMenu_4);
//        web.clickLink_Web(subMenu_text);
        web.removeFieldLocation_Web();
    }

    @QAFTestStep(description = "D365-Fin: Click-Back")
    @And("D365-Fin: Click-Back")
    public static void d365Fin_clickBack() throws Exception {
        web.setFieldLocation_Web("tool_bar_main");
        web.clickButton_Web("Back");
        web.removeFieldLocation_Web();
    }

    /**
     * @param tab_text [Tab Text/name to be clicked]
     */
    @And("D365-Fin: Click-Tab Text:{string}")
    @QAFTestStep(description = "D365-Fin: Click-Tab Text:{string}")
    public static void d365Fin_clickTab(String tab_text) throws Exception {
        web.clickTab_Web(tab_text);
    }

    /**
     * @param view_text [Tab Text/name to be clicked]
     */
    @And("D365-Fin: Change-View-To Text:{string}")
    @QAFTestStep(description = "D365-Fin: Change-View-To Text:{string}")
    public static void d365Fin_changeViewTo(String view_text) throws Exception {
        web.setFieldLocation_Web("header_bar");
        web.clickButton_Web("SystemDefinedManageViewFilters");
        BrowserGlobal.iWaitForSeconds("2");
        web.setFieldLocation_Web("dialog");
        web.clickButton_Web(view_text);
        web.removeFieldLocation_Web();
    }

    /**
     */
    @And("D365-Fin: Sign-Out")
    @QAFTestStep(description = "D365-Fin: Sign-Out")
    public static void d365Fin_signOut() throws Exception {
        web.setFieldLocation_Web("nav_bar");
//        getBundle().setProperty("loc.auto.idValue","UserBtn");
        BrowserGlobal.iStoreValueIntoVariable("UserBtn","loc.auto.idValue");
        web.clickButton_Web("UserBtn");
        BrowserGlobal.iStoreValueIntoVariable("","loc.auto.idValue");
//        getBundle().setProperty("","loc.auto.idValue");
        web.setFieldLocation_Web("menu_drop_down");
        web.clickButton_Web("Sign out");
        web.removeFieldLocation_Web();
    }

    /**
     *
     */
    @And("D365-Fin: Wait-For-Loader-To-Disappear")
    @QAFTestStep(description = "D365-Fin: Wait-For-Loader-To-Disappear")
    public static void d365Fin_waitForLoaderToDisappear() throws Exception {
        web.waitForLoaderToDisappear_Web("");
    }


}
