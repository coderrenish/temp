package com.ahq.pages;


import com.ahq.globals.*;
import com.qmetry.qaf.automation.step.QAFTestStep;
import io.cucumber.java.en.And;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

public class athenaLoginPage {
    @QAFTestStep(description = "Test Data Creation: Login to Athena with following details Url:{0}, Username:{1} and Password:{2}")
    @And("Test Data Creation: Login to Athena with following details Url:{string}, Username:{string} and Password:{string}")
    public void iLoginToAthenaForTestDataCreation(String url, String username, String password) throws Exception {
        String getRunTrigger = getBundle().getPropertyValue("runTrigger");
        if (getRunTrigger.equalsIgnoreCase("runTrigger")) {
            D365CRM.loginTo_D365CRM("Athena",url,username,password);
            D365CRM.waitAndVerifyPageHeader_D365CRM("Dashboard Notification","Home");
            D365CRM.clickLeftMenu_D365CRM("Membership Management");
            getBundle().setProperty("runTrigger","YES");
        } else {
            D365CRM.clickLeftMenu_D365CRM("Home");
            D365CRM.waitAndVerifyPageHeader_D365CRM("Dashboard Notification","Home");
        }
    }
}

