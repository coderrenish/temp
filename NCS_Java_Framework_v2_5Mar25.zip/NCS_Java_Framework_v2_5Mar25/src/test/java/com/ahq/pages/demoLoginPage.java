package com.ahq.pages;

import com.ahq.globals.*;
//import com.qmetry.qaf.automation.*;
//import com.ahq.BrowserGlobal.utils.*;
import com.ahq.addons.*;
//import com.ahq.utils.nics_singapore;
import com.qmetry.qaf.automation.step.QAFTestStep;
import io.cucumber.java.en.And;

import java.util.List;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;


public class demoLoginPage {
    @QAFTestStep(description = "Login: I login to SauseDemo using {0}, {1} and {2}")
    @And("Login: I login to SauseDemo using {string}, {string} and {string}")
    public void iLoginToSauseDemo(String url, String username, String password) throws Exception {
        web.setPageName_Web("Login Page");
        web.openBrowser_Web(url);
        web.inputTextWithPlaceholderOrNoLabel_Web(username, "Username");
        web.inputTextWithPlaceholderOrNoLabel_Web(password, "Password");
        web.clickButton_Web("Login");
        System.out.println("PASSPORT ===> " + Utils.passport_generate("SGP"));
//        System.out.println("=========> " + com.ahq.globals.Utils.nric_singapore_generate("G","1990-2010"));
        System.out.println("EXCEL READ/WRITE ===> ");




//        utilsExcel.writeToExcel("./resources/data/uploads/Sponsored_MembershipTemplate.xlsx","Sheet1","[[A13,Batch 1];[C13,24/04/2009,dd/MM/yyyy];[E13,0.00,#\\,##0.00]; [H13,NRIC] ; [I13,##\\,#Some Text ~{NRIC::G::1990-2010} to ~{NRIC::T::1990-2010} continue ~{PASSPORT::SGP}]]");
//        utilsExcel.writeToExcel("./resources/data/uploads/Test_Conveyance_Request.xlsx","Conveyance Request Details","[[A13,Batch 1];[C13,24/04/2009];[E13,0,#\\,##0.00]; [H13,NRIC] ; [I13,##\\,#Some Text ~{NRIC::G::1990-2010} to ~{NRIC::T::1990-2010} continue ~{PASSPORT::SGP}]]");
    }



}

